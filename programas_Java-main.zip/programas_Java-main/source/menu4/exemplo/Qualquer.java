package br.univates.source.menu4.exemplo;

import br.univates.source.menu4.MenuProcesso;

public class Qualquer
{
    private MenuProcesso processo;

    public Qualquer(MenuProcesso processo)
    {
        this.processo = processo;
    }

    public MenuProcesso getProcesso()
    {
        return processo;
    }
    
    
}
