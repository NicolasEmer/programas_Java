package br.univates.source.menu4.exemplo;

import br.univates.source.menu4.MenuProcesso;

public class Processo01_old implements MenuProcesso
{

    @Override
    public void executar()
    {
        System.out.println("O processo 01 foi executado");
    }
    
}
