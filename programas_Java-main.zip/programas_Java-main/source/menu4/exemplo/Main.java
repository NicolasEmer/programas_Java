package br.univates.source.menu4.exemplo;

import br.univates.source.menu4.Menu;
import br.univates.source.menu4.MenuItem;
import java.util.ArrayList;

public class Main
{
    public static void main(String[] args)
    {
        TelaUltimate t = new TelaUltimate();
        t.exibir();
        
        System.exit(0);
    }
}
