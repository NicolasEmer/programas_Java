package br.univates.source.menu4;

public interface MenuProcesso
{
    public void executar();
}
