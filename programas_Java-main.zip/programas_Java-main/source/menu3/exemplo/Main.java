package br.univates.source.menu3.exemplo;


public class Main
{
    public static void main(String[] args)
    {
        TelaExemplo t = new TelaExemplo();
        t.exibir();
    }
}
