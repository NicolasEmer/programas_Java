/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univates.source.persistence.exemplo2;

import br.univates.source.persistence.exemplo1.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author mouriac
 */
public class Teste1
{
    public static void main(String[] args)
    {
//        FuncionarioDao dao = new FuncionarioDao();
//        
//        try
//        {
//            dao.create( new Funcionario(1,"Juca","Lajeado") );
//            System.out.println("Deu tudo certo");
//        } 
//        catch (KeyViolationException ex)
//        {
//            // exibir a mensagem de erro para o usuário
//            //JOptionPane.showMessageDialog(null, ex.getMessage() );
//            JOptionPane.showMessageDialog(null, ex.getMessage(), "Atenção", JOptionPane.ERROR_MESSAGE );
//        }

    }
}
