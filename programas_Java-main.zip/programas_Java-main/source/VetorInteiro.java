package br.univates.source;

public class VetorInteiro 
{
    int[] vetor;
    
    public double media()
    {
        return 0;
    }
}
