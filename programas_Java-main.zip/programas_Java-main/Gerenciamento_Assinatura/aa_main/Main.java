/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univates.aa_main;


import br.univates.apresentacao.Tela_Menu;

/**
 *
 * @author nicolas.emer
 */
public class Main {
    public static void main(String[] args) {
        
        Tela_Menu tel = new Tela_Menu();
        tel.setVisible(true);
    }
}
